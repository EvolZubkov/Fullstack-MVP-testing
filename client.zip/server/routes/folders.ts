import { Router } from "express";
import { storage } from "../storage";
import { requireAuth, requireAuthor } from "../middleware/auth";

const router = Router();

// GET /api/folders - Список папок
router.get("/", requireAuth, async (req, res) => {
  try {
    const folders = await storage.getFolders();
    res.json(folders);
  } catch (error) {
    console.error("Get folders error:", error);
    res.status(500).json({ error: "Failed to get folders" });
  }
});

// POST /api/folders - Создать папку
router.post("/", requireAuthor, async (req, res) => {
  try {
    const { name, parentId } = req.body;
    if (!name) {
      return res.status(400).json({ error: "Name required" });
    }
    const folder = await storage.createFolder({ name, parentId: parentId || null });
    res.status(201).json(folder);
  } catch (error) {
    console.error("Create folder error:", error);
    res.status(500).json({ error: "Failed to create folder" });
  }
});

// PUT /api/folders/:id - Обновить папку
router.put("/:id", requireAuthor, async (req, res) => {
  try {
    const { name, parentId } = req.body;
    const updated = await storage.updateFolder(req.params.id, { name, parentId });
    if (!updated) {
      return res.status(404).json({ error: "Folder not found" });
    }
    res.json(updated);
  } catch (error) {
    console.error("Update folder error:", error);
    res.status(500).json({ error: "Failed to update folder" });
  }
});

// DELETE /api/folders/:id - Удалить папку
router.delete("/:id", requireAuthor, async (req, res) => {
  try {
    const success = await storage.deleteFolder(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "Folder not found" });
    }
    res.json({ success: true });
  } catch (error) {
    console.error("Delete folder error:", error);
    res.status(500).json({ error: "Failed to delete folder" });
  }
});

export default router;