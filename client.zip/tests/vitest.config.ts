import { defineConfig } from "vitest/config";
import path from "path";

export default defineConfig({
  test: {
    globals: true,
    environment: "node",
    include: ["tests/**/*.test.ts", "tests/**/*.test.js"],
  },
  resolve: {
    alias: {
      "@shared": path.resolve(__dirname, "testing-shared"),
      "@": path.resolve(__dirname, "testing-client/src"),
    },
  },
});
